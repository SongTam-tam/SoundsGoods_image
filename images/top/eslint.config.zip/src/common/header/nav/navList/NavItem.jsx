import React from 'react';

const NavItem = ({ title }) => {
    return <li>{title}</li>;
};

export default NavItem;
