// export { default as xxx } from './xxx';  export { default as 내보내는 파일 이름 } from './폴더명';
export { default as Main } from './main';
export { default as Login } from './login';
export { default as Oauth } from './oauth';
