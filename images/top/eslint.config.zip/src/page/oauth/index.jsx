import React from 'react';

const Oauth = () => {
    return <div></div>;
};

export default Oauth;
